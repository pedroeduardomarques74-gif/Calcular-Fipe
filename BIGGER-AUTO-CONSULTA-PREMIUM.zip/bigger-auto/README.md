# BIGGER AUTO v2

Aplicativo Android nativo para consulta FIPE e estrutura de consulta veicular/cautelar por placa.

## Já funciona
- Carros, motos e caminhões na FIPE.
- Marca > modelo > ano/combustível > valor, código FIPE e referência.
- Interface da consulta completa por placa.
- Módulos: leilão, sinistro, roubo/furto, restrições, débitos/multas, recall, proprietários e quilometragem.
- Estados separados: ENCONTRADO, NADA CONSTA e NÃO CONSULTADO.
- Compartilhamento de relatório textual.
- Chassi e Renavam mascarados na interface.

## Para ativar dados completos por placa
A consulta histórica/cautelar depende de um fornecedor autorizado. No GitHub, abra:
Settings > Secrets and variables > Actions > New repository secret

Crie:
- VEHICLE_API_BASE = endpoint HTTPS do seu fornecedor. O app adiciona `?placa=ABC1D23` (ou `&placa=` se já houver query string).
- VEHICLE_API_KEY = chave/token. O app envia `Authorization: Bearer SUA_CHAVE`.

### Contrato de resposta esperado
O app aceita o objeto na raiz ou dentro de `data` e reconhece nomes em PT/EN. Exemplo:
```json
{
  "data": {
    "marca": "Ford",
    "modelo": "Maverick",
    "versao": "Lariat FX4",
    "anoModelo": "2024",
    "cor": "Cinza",
    "combustivel": "Gasolina",
    "municipio": "Colatina",
    "uf": "ES",
    "chassi": "...",
    "renavam": "...",
    "valorFipe": "R$ 170.000,00",
    "codigoFipe": "000000-0",
    "leilao": {"status":"nada consta", "detalhe":""},
    "sinistro": {"status":"encontrado", "detalhe":"Registro informado pela fonte"},
    "rouboFurto": {"status":"nada consta"},
    "restricoes": {"status":"nada consta"},
    "debitosMultas": {"status":"não consultado"},
    "recall": {"status":"nada consta"},
    "historicoProprietarios": {"status":"não consultado"},
    "quilometragem": {"status":"não consultado"}
  }
}
```

Se o seu fornecedor usar outro endpoint, autenticação ou formato JSON, adapte `consultVehicle()` / `parseVehicleReport()` em `MainActivity.java`.

## Gerar APK
O workflow `.github/workflows/build-apk.yml` gera o APK em Actions > Artifacts.

## Importante
O módulo “cautelar” do app é histórico/dados. Inspeção física de estrutura, pintura, soldas, longarinas e etiquetas exige vistoria presencial ou integração específica com uma empresa de vistoria.
