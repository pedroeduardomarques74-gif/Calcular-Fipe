plugins {
    id("com.android.application")
}

fun esc(value: String): String = value.replace("\\", "\\\\").replace("\"", "\\\"")
val vehicleApiBase = (project.findProperty("VEHICLE_API_BASE") as String?) ?: ""
val vehicleApiKey = (project.findProperty("VEHICLE_API_KEY") as String?) ?: ""

android {
    namespace = "com.grupobigger.biggerauto"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.grupobigger.biggerauto"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
        buildConfigField("String", "VEHICLE_API_BASE", "\"${esc(vehicleApiBase)}\"")
        buildConfigField("String", "VEHICLE_API_KEY", "\"${esc(vehicleApiKey)}\"")
    }

    buildFeatures { buildConfig = true }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}
