package com.grupobigger.biggerauto;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String FIPE_BASE = "https://parallelum.com.br/fipe/api/v1/";

    // Configure estes dois valores pelo GitHub Actions (Secrets) quando contratar um provedor.
    private static final String VEHICLE_API_BASE = BuildConfig.VEHICLE_API_BASE;
    private static final String VEHICLE_API_KEY = BuildConfig.VEHICLE_API_KEY;

    private final int BG = Color.rgb(7, 10, 22), CARD = Color.rgb(17, 24, 43);
    private final int CARD2 = Color.rgb(24, 34, 59), BLUE = Color.rgb(55, 116, 255);
    private final int PURPLE = Color.rgb(151, 71, 255), CYAN = Color.rgb(0, 200, 225);
    private final int GREEN = Color.rgb(31, 211, 144), YELLOW = Color.rgb(255, 190, 50);
    private final int RED = Color.rgb(255, 83, 112), MUTED = Color.rgb(164, 177, 204);

    private LinearLayout content;
    private ProgressBar progress;
    private String tipo = "carros";
    private Spinner brandSpinner, modelSpinner, yearSpinner;
    private final List<Item> brands = new ArrayList<>(), models = new ArrayList<>(), years = new ArrayList<>();
    private VehicleReport lastReport;

    @Override protected void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); showHome(); }

    private void root() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackground(gradient(BG, Color.rgb(13, 18, 39), 0));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(17),dp(22),dp(17),dp(34));
        scroll.addView(content); frame.addView(scroll,new FrameLayout.LayoutParams(-1,-1));
        progress = new ProgressBar(this); progress.setVisibility(View.GONE);
        frame.addView(progress,new FrameLayout.LayoutParams(dp(52),dp(52),Gravity.CENTER));
        setContentView(frame);
    }

    private void showHome() {
        root();
        TextView logo=txt("BIGGER AUTO",31,Color.WHITE,true); logo.setLetterSpacing(.07f); content.addView(logo);
        content.addView(txt("Consulta veicular • FIPE • Histórico • Cautelar",14,MUTED,false),marginTop(3));

        LinearLayout hero=cardGradient(BLUE,PURPLE);
        hero.addView(txt("🚘  Consulte antes de comprar",14,Color.WHITE,true));
        hero.addView(txt("Conheça o veículo\nantes de fechar negócio.",28,Color.WHITE,true),marginTop(8));
        hero.addView(txt("Dados cadastrais, valor FIPE e módulos de procedência em uma única ficha.",14,Color.WHITE,false),marginTop(10));
        content.addView(hero,marginTop(20));

        Button complete=button("🔎  CONSULTA COMPLETA POR PLACA",PURPLE); complete.setOnClickListener(v->showPlate());
        content.addView(complete,marginTopHeight(18,64));
        Button fipe=button("💰  CONSULTAR TABELA FIPE",BLUE); fipe.setOnClickListener(v->showFipe());
        content.addView(fipe,marginTopHeight(10,60));

        content.addView(sectionTitle("O que a consulta pode reunir"),marginTop(26));
        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        grid.addView(moduleRow("🛡️","Cautelar e procedência","Leilão, sinistro, restrições e histórico"));
        grid.addView(moduleRow("🚨","Débitos e segurança","Multas/débitos, roubo/furto e bloqueios"));
        grid.addView(moduleRow("📋","Dados do veículo","Marca, modelo, ano, cor, combustível e mais"));
        grid.addView(moduleRow("💵","Mercado e FIPE","Valor de referência e código FIPE"));
        grid.addView(moduleRow("🧰","Recall e observações","Pendências e alertas informados pela fonte"));
        content.addView(grid);

        LinearLayout safe=card();
        safe.addView(txt("✓ RESULTADO RESPONSÁVEL",13,GREEN,true));
        safe.addView(txt("O BIGGER AUTO diferencia “Nada consta” de “Não consultado”. Se uma fonte não responder, o app não transforma isso em resultado positivo.",14,MUTED,false),marginTop(7));
        content.addView(safe,marginTop(18));
    }

    private View moduleRow(String icon,String title,String sub){
        LinearLayout row=card(); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView i=txt(icon,27,Color.WHITE,false); i.setGravity(Gravity.CENTER); row.addView(i,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout text=new LinearLayout(this); text.setOrientation(LinearLayout.VERTICAL); text.setPadding(dp(10),0,0,0);
        text.addView(txt(title,16,Color.WHITE,true)); text.addView(txt(sub,13,MUTED,false),marginTop(3));
        row.addView(text,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams p=marginTop(9); row.setLayoutParams(p); return row;
    }

    private void showPlate(){
        root(); addTop("CONSULTA COMPLETA",this::showHome);
        LinearLayout box=cardGradient(Color.rgb(45,65,150),PURPLE);
        box.addView(txt("Digite a placa",16,Color.WHITE,true));
        EditText plate=new EditText(this); plate.setHint("ABC1D23"); plate.setHintTextColor(Color.rgb(115,125,151)); plate.setTextColor(Color.WHITE);
        plate.setTextSize(26); plate.setGravity(Gravity.CENTER); plate.setSingleLine(true); plate.setAllCaps(true);
        plate.setFilters(new InputFilter[]{new InputFilter.LengthFilter(7)}); plate.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        plate.setBackground(rounded(Color.rgb(8,13,31),dp(16))); box.addView(plate,marginTopHeight(14,66));
        Button go=button("CONSULTAR HISTÓRICO E CAUTELAR",CYAN); box.addView(go,marginTopHeight(12,58)); content.addView(box,marginTop(18));

        content.addView(sectionTitle("Módulos da consulta"),marginTop(24));
        content.addView(statusPreview("Leilão","Aguardando consulta")); content.addView(statusPreview("Sinistro","Aguardando consulta"));
        content.addView(statusPreview("Roubo / furto","Aguardando consulta")); content.addView(statusPreview("Restrições","Aguardando consulta"));
        content.addView(statusPreview("Débitos / multas","Aguardando consulta")); content.addView(statusPreview("Recall","Aguardando consulta"));

        LinearLayout notice=card(); notice.addView(txt("ℹ️ Sobre a cautelar",16,YELLOW,true));
        notice.addView(txt("Este módulo é uma consulta de histórico/dados. Uma vistoria cautelar física de estrutura, pintura, soldas, etiquetas e longarinas exige inspeção presencial ou integração com empresa de vistoria.",13,MUTED,false),marginTop(7));
        content.addView(notice,marginTop(16));

        go.setOnClickListener(v->{
            String p=normalizePlate(plate.getText().toString());
            if(!validPlate(p)){ toast("Digite uma placa válida, exemplo ABC1D23"); return; }
            consultVehicle(p);
        });
    }

    private View statusPreview(String title,String value){
        LinearLayout r=card(); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(txt(title,15,Color.WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView s=badge(value,MUTED); r.addView(s); LinearLayout.LayoutParams p=marginTop(7); r.setLayoutParams(p); return r;
    }

    private void consultVehicle(String plate){
        if(VEHICLE_API_BASE==null || VEHICLE_API_BASE.trim().isEmpty()){
            showProviderNeeded(plate); return;
        }
        setLoading(true);
        try{
            String sep=VEHICLE_API_BASE.contains("?")?"&":"?";
            String url=VEHICLE_API_BASE+sep+"placa="+URLEncoder.encode(plate, StandardCharsets.UTF_8.name());
            request(url,VEHICLE_API_KEY,json->{
                try { VehicleReport r=parseVehicleReport(plate,new JSONObject(json)); lastReport=r; showVehicleReport(r); setLoading(false); }
                catch(Exception e){ fail("O provedor respondeu, mas o formato dos dados não corresponde ao configurado."); }
            });
        }catch(Exception e){ fail("Não foi possível preparar a consulta."); }
    }

    private void showProviderNeeded(String plate){
        root(); addTop("CONSULTA "+plate,this::showPlate);
        LinearLayout h=cardGradient(PURPLE,Color.rgb(60,76,180));
        h.addView(txt("🔌 Integração pronta",14,Color.WHITE,true)); h.addView(txt("Falta conectar a fonte de dados",25,Color.WHITE,true),marginTop(7));
        h.addView(txt("A interface da consulta completa já está no aplicativo. Para retornar leilão, sinistro, restrições, débitos e demais registros reais, configure VEHICLE_API_BASE e VEHICLE_API_KEY nos Secrets do GitHub.",14,Color.WHITE,false),marginTop(9));
        content.addView(h,marginTop(18));
        content.addView(resultModule("Leilão","NÃO CONSULTADO","Fornecedor não configurado",MUTED),marginTop(14));
        content.addView(resultModule("Sinistro","NÃO CONSULTADO","Fornecedor não configurado",MUTED),marginTop(8));
        content.addView(resultModule("Roubo / furto","NÃO CONSULTADO","Fornecedor não configurado",MUTED),marginTop(8));
        content.addView(resultModule("Restrições","NÃO CONSULTADO","Fornecedor não configurado",MUTED),marginTop(8));
        content.addView(resultModule("Débitos / multas","NÃO CONSULTADO","Fornecedor não configurado",MUTED),marginTop(8));
        content.addView(resultModule("Recall","NÃO CONSULTADO","Fornecedor não configurado",MUTED),marginTop(8));
    }

    private VehicleReport parseVehicleReport(String plate,JSONObject root){
        JSONObject d=root.optJSONObject("data"); if(d==null)d=root;
        VehicleReport r=new VehicleReport(); r.plate=plate;
        r.brand=pick(d,"marca","brand"); r.model=pick(d,"modelo","model"); r.version=pick(d,"versao","version");
        r.year=pick(d,"anoModelo","ano_modelo","year"); r.color=pick(d,"cor","color"); r.fuel=pick(d,"combustivel","fuel");
        r.city=pick(d,"municipio","cidade","city"); r.state=pick(d,"uf","state"); r.chassis=mask(pick(d,"chassi","chassis"));
        r.renavam=mask(pick(d,"renavam")); r.fipe=pick(d,"valorFipe","valor_fipe","fipe"); r.fipeCode=pick(d,"codigoFipe","codigo_fipe","fipe_code");
        r.auction=module(d,"leilao","auction"); r.claim=module(d,"sinistro","claim","accident"); r.theft=module(d,"rouboFurto","roubo_furto","theft");
        r.restrictions=module(d,"restricoes","restrictions"); r.debts=module(d,"debitosMultas","debitos","multas","debts"); r.recall=module(d,"recall");
        r.ownerHistory=module(d,"historicoProprietarios","proprietarios","owner_history"); r.odometer=module(d,"quilometragem","odometer");
        r.score=calculateScore(r); return r;
    }

    private Module module(JSONObject d,String... keys){
        for(String k:keys){ if(!d.has(k)||d.isNull(k))continue; Object o=d.opt(k);
            if(o instanceof JSONObject){ JSONObject j=(JSONObject)o; String st=pick(j,"status","situacao","result"); String detail=pick(j,"detalhe","descricao","detail","message"); return new Module(normalizeStatus(st),detail); }
            if(o instanceof Boolean) return new Module(((Boolean)o)?"ENCONTRADO":"NADA CONSTA","");
            String s=String.valueOf(o); return new Module(normalizeStatus(s),s);
        }
        return new Module("NÃO CONSULTADO","Fonte não retornou este módulo");
    }

    private String normalizeStatus(String s){
        if(s==null||s.trim().isEmpty())return "NÃO CONSULTADO"; String x=s.toLowerCase(Locale.ROOT);
        if(x.contains("nada")||x.contains("limpo")||x.equals("false")||x.contains("sem registro")||x.equals("ok"))return "NADA CONSTA";
        if(x.contains("encontr")||x.contains("consta")||x.contains("alert")||x.contains("sim")||x.equals("true")||x.contains("restri"))return "ENCONTRADO";
        return s.toUpperCase(Locale.ROOT);
    }

    private int calculateScore(VehicleReport r){ int score=100; Module[] risk={r.auction,r.claim,r.theft,r.restrictions,r.debts}; for(Module m:risk) if("ENCONTRADO".equals(m.status))score-=18; return Math.max(10,score); }

    private void showVehicleReport(VehicleReport r){
        root(); addTop("DOSSIÊ DO VEÍCULO",this::showPlate);
        int riskColor=r.score>=82?GREEN:r.score>=55?YELLOW:RED; String risk=r.score>=82?"SEM ALERTAS RELEVANTES":r.score>=55?"ATENÇÃO":"ALERTAS IMPORTANTES";
        LinearLayout head=cardGradient(Color.rgb(40,57,130),PURPLE);
        head.addView(txt("PLACA  "+r.plate,14,Color.WHITE,true)); head.addView(txt(nonEmpty(r.brand+" "+r.model,"Veículo consultado"),25,Color.WHITE,true),marginTop(6));
        head.addView(txt(join(" • ",r.version,r.year,r.fuel),14,Color.WHITE,false),marginTop(6));
        TextView riskBadge=badge(risk,riskColor); head.addView(riskBadge,marginTop(15)); content.addView(head,marginTop(18));

        content.addView(sectionTitle("Procedência e cautelar"),marginTop(23));
        content.addView(resultModule("Leilão",r.auction.status,r.auction.detail,colorFor(r.auction.status)),marginTop(8));
        content.addView(resultModule("Sinistro",r.claim.status,r.claim.detail,colorFor(r.claim.status)),marginTop(8));
        content.addView(resultModule("Roubo / furto",r.theft.status,r.theft.detail,colorFor(r.theft.status)),marginTop(8));
        content.addView(resultModule("Restrições",r.restrictions.status,r.restrictions.detail,colorFor(r.restrictions.status)),marginTop(8));
        content.addView(resultModule("Débitos / multas",r.debts.status,r.debts.detail,colorFor(r.debts.status)),marginTop(8));
        content.addView(resultModule("Recall",r.recall.status,r.recall.detail,colorFor(r.recall.status)),marginTop(8));
        content.addView(resultModule("Histórico de proprietários",r.ownerHistory.status,r.ownerHistory.detail,colorFor(r.ownerHistory.status)),marginTop(8));
        content.addView(resultModule("Quilometragem",r.odometer.status,r.odometer.detail,colorFor(r.odometer.status)),marginTop(8));

        content.addView(sectionTitle("Ficha cadastral"),marginTop(23));
        LinearLayout info=card(); info.addView(detail("Marca",r.brand)); info.addView(detail("Modelo",r.model)); info.addView(detail("Versão",r.version));
        info.addView(detail("Ano modelo",r.year)); info.addView(detail("Cor",r.color)); info.addView(detail("Combustível",r.fuel)); info.addView(detail("Município/UF",join("/",r.city,r.state)));
        info.addView(detail("Chassi",r.chassis)); info.addView(detail("Renavam",r.renavam)); info.addView(detail("FIPE",r.fipe)); info.addView(detail("Código FIPE",r.fipeCode)); content.addView(info,marginTop(10));

        Button share=button("📄  COMPARTILHAR RELATÓRIO",BLUE); share.setOnClickListener(v->shareReport(r)); content.addView(share,marginTopHeight(18,60));
        content.addView(txt("Resultado baseado exclusivamente nas fontes configuradas. “Não consultado” não significa “nada consta”.",12,MUTED,false),marginTop(12));
    }

    private View resultModule(String title,String status,String detail,int color){
        LinearLayout box=card(); LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(txt(title,15,Color.WHITE,true),new LinearLayout.LayoutParams(0,-2,1)); top.addView(badge(status,color)); box.addView(top);
        if(detail!=null&&!detail.trim().isEmpty()&&!detail.equalsIgnoreCase(status)) box.addView(txt(detail,12,MUTED,false),marginTop(7)); return box;
    }

    private int colorFor(String s){ if("NADA CONSTA".equals(s))return GREEN; if("ENCONTRADO".equals(s))return RED; return YELLOW; }

    private void shareReport(VehicleReport r){
        String report="BIGGER AUTO — RELATÓRIO VEICULAR\n\nPlaca: "+r.plate+"\nVeículo: "+join(" ",r.brand,r.model,r.version)+"\nAno: "+r.year+"\nFIPE: "+r.fipe+
                "\n\nCAUTELAR / HISTÓRICO\nLeilão: "+r.auction.status+"\nSinistro: "+r.claim.status+"\nRoubo/Furto: "+r.theft.status+"\nRestrições: "+r.restrictions.status+
                "\nDébitos/Multas: "+r.debts.status+"\nRecall: "+r.recall.status+"\n\nObs.: Não consultado não significa nada consta.";
        Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,report); startActivity(Intent.createChooser(i,"Compartilhar relatório"));
    }

    private void showFipe(){
        root(); addTop("CONSULTAR FIPE",this::showHome);
        content.addView(txt("Selecione a categoria",14,MUTED,false),marginTop(12));
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button c=smallButton("🚗 Carros"),m=smallButton("🏍️ Motos"),t=smallButton("🚛 Caminhões"); row.addView(c,weighted());row.addView(m,weighted());row.addView(t,weighted());content.addView(row,marginTop(10));
        LinearLayout form=card(); form.addView(label("Marca")); brandSpinner=spinner();form.addView(brandSpinner,lp(-1,dp(56))); form.addView(label("Modelo"),marginTop(13)); modelSpinner=spinner();form.addView(modelSpinner,lp(-1,dp(56))); form.addView(label("Ano / combustível"),marginTop(13));yearSpinner=spinner();form.addView(yearSpinner,lp(-1,dp(56)));
        Button go=button("CONSULTAR VALOR FIPE",BLUE);form.addView(go,marginTopHeight(18,58));content.addView(form,marginTop(18));
        c.setOnClickListener(v->{tipo="carros";loadBrands();});m.setOnClickListener(v->{tipo="motos";loadBrands();});t.setOnClickListener(v->{tipo="caminhoes";loadBrands();});go.setOnClickListener(v->consultFipe());
        brandSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?>p){} public void onItemSelected(AdapterView<?>p,View v,int pos,long id){if(pos>=0&&pos<brands.size())loadModels(brands.get(pos).code);}});
        modelSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?>p){} public void onItemSelected(AdapterView<?>p,View v,int pos,long id){int b=brandSpinner.getSelectedItemPosition();if(pos>=0&&pos<models.size()&&b>=0&&b<brands.size())loadYears(brands.get(b).code,models.get(pos).code);}});
        loadBrands();
    }

    private void loadBrands(){setLoading(true);request(FIPE_BASE+tipo+"/marcas","",json->{try{brands.clear();JSONArray a=new JSONArray(json);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);brands.add(new Item(o.getString("codigo"),o.getString("nome")));}setSpinner(brandSpinner,brands);setLoading(false);}catch(Exception e){fail("Resposta inválida da API FIPE.");}});}
    private void loadModels(String b){setLoading(true);request(FIPE_BASE+tipo+"/marcas/"+b+"/modelos","",json->{try{models.clear();JSONArray a=new JSONObject(json).getJSONArray("modelos");for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);models.add(new Item(o.getString("codigo"),o.getString("nome")));}setSpinner(modelSpinner,models);setLoading(false);}catch(Exception e){fail("Não foi possível carregar os modelos.");}});}
    private void loadYears(String b,String m){setLoading(true);request(FIPE_BASE+tipo+"/marcas/"+b+"/modelos/"+m+"/anos","",json->{try{years.clear();JSONArray a=new JSONArray(json);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);years.add(new Item(o.getString("codigo"),o.getString("nome")));}setSpinner(yearSpinner,years);setLoading(false);}catch(Exception e){fail("Não foi possível carregar os anos.");}});}
    private void consultFipe(){int b=brandSpinner.getSelectedItemPosition(),m=modelSpinner.getSelectedItemPosition(),y=yearSpinner.getSelectedItemPosition();if(b<0||m<0||y<0||b>=brands.size()||m>=models.size()||y>=years.size()){toast("Aguarde os dados carregarem.");return;}setLoading(true);String u=FIPE_BASE+tipo+"/marcas/"+brands.get(b).code+"/modelos/"+models.get(m).code+"/anos/"+years.get(y).code;request(u,"",json->{try{JSONObject o=new JSONObject(json);showFipeResult(o);setLoading(false);}catch(Exception e){fail("Não foi possível ler a ficha FIPE.");}});}
    private void showFipeResult(JSONObject o){root();addTop("RESULTADO FIPE",this::showFipe);LinearLayout r=cardGradient(Color.rgb(32,93,115),Color.rgb(30,119,88));r.addView(txt(o.optString("Marca"),14,Color.WHITE,true));r.addView(txt(o.optString("Modelo"),24,Color.WHITE,true),marginTop(6));r.addView(txt(o.optString("AnoModelo")+" • "+o.optString("Combustivel"),14,Color.WHITE,false),marginTop(7));r.addView(txt(o.optString("Valor"),35,Color.WHITE,true),marginTop(22));r.addView(txt("Valor de referência",12,Color.WHITE,false));content.addView(r,marginTop(18));LinearLayout d=card();d.addView(detail("Código FIPE",o.optString("CodigoFipe")));d.addView(detail("Mês de referência",o.optString("MesReferencia")));content.addView(d,marginTop(12));}

    private void request(String u,String key,Callback cb){new Thread(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(18000);c.setRequestProperty("Accept","application/json");if(key!=null&&!key.trim().isEmpty())c.setRequestProperty("Authorization","Bearer "+key);int code=c.getResponseCode();if(code<200||code>=300)throw new Exception("HTTP "+code);BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder sb=new StringBuilder();String line;while((line=br.readLine())!=null)sb.append(line);br.close();String out=sb.toString();runOnUiThread(()->cb.ok(out));}catch(Exception e){runOnUiThread(()->fail("Serviço indisponível ou sem conexão. Tente novamente."));}finally{if(c!=null)c.disconnect();}}).start();}

    private String pick(JSONObject j,String...ks){for(String k:ks){String v=j.optString(k,"");if(v!=null&&!v.trim().isEmpty()&&!"null".equalsIgnoreCase(v))return v;}return "Não informado";}
    private String mask(String s){if(s==null||s.equals("Não informado"))return "Não informado";if(s.length()<=4)return "••••";return "••••••"+s.substring(Math.max(0,s.length()-4));}
    private String normalizePlate(String s){return s.replaceAll("[^A-Za-z0-9]","").toUpperCase(Locale.ROOT);}
    private boolean validPlate(String p){return p.matches("[A-Z]{3}[0-9][A-Z0-9][0-9]{2}");}
    private String nonEmpty(String s,String fallback){return s==null||s.trim().isEmpty()?fallback:s.trim();}
    private String join(String sep,String...v){StringBuilder b=new StringBuilder();for(String x:v){if(x==null||x.trim().isEmpty()||x.equals("Não informado"))continue;if(b.length()>0)b.append(sep);b.append(x.trim());}return b.length()==0?"Não informado":b.toString();}

    private void addTop(String title,Runnable back){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);Button b=smallButton("←");b.setTextSize(23);b.setOnClickListener(v->back.run());row.addView(b,new LinearLayout.LayoutParams(dp(54),dp(50)));TextView t=txt(title,19,Color.WHITE,true);t.setGravity(Gravity.CENTER);row.addView(t,new LinearLayout.LayoutParams(0,dp(50),1));row.addView(new View(this),new LinearLayout.LayoutParams(dp(54),dp(50)));content.addView(row);}
    private TextView sectionTitle(String s){return txt(s,19,Color.WHITE,true);}
    private TextView badge(String s,int c){TextView v=txt(s,11,Color.WHITE,true);v.setPadding(dp(10),dp(7),dp(10),dp(7));v.setGravity(Gravity.CENTER);v.setBackground(rounded(c,dp(20)));return v;}
    private View detail(String a,String b){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setPadding(0,dp(9),0,dp(9));r.addView(txt(a,13,MUTED,false),new LinearLayout.LayoutParams(0,-2,1));TextView v=txt(nonEmpty(b,"Não informado"),13,Color.WHITE,true);v.setGravity(Gravity.END);r.addView(v,new LinearLayout.LayoutParams(0,-2,1.5f));return r;}
    private void setSpinner(Spinner s,List<Item> items){List<String> names=new ArrayList<>();for(Item i:items)names.add(i.name);ArrayAdapter<String> a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names){@Override public View getView(int p,View c,ViewGroup par){TextView v=(TextView)super.getView(p,c,par);v.setTextColor(Color.WHITE);v.setTextSize(15);v.setPadding(dp(12),0,dp(12),0);return v;}@Override public View getDropDownView(int p,View c,ViewGroup par){TextView v=(TextView)super.getDropDownView(p,c,par);v.setTextColor(Color.BLACK);v.setPadding(dp(14),dp(14),dp(14),dp(14));return v;}};s.setAdapter(a);}
    private Spinner spinner(){Spinner s=new Spinner(this);s.setBackground(rounded(Color.rgb(8,14,31),dp(14)));return s;}
    private LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(17),dp(17),dp(17),dp(17));l.setBackground(rounded(CARD,dp(19)));return l;}
    private LinearLayout cardGradient(int a,int b){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(20),dp(22),dp(20),dp(22));l.setBackground(gradient(a,b,dp(23)));return l;}
    private TextView label(String s){return txt(s,13,MUTED,true);}
    private Button smallButton(String s){Button b=button(s,CARD2);b.setTextSize(12);b.setPadding(dp(4),0,dp(4),0);return b;}
    private Button button(String s,int c){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setAllCaps(false);b.setGravity(Gravity.CENTER);b.setBackground(rounded(c,dp(16)));return b;}
    private TextView txt(String s,int sp,int c,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(c);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setLineSpacing(dp(2),1f);return v;}
    private GradientDrawable rounded(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(r);return g;}
    private GradientDrawable gradient(int a,int b,int r){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});g.setCornerRadius(r);return g;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams marginTop(int t){LinearLayout.LayoutParams p=lp(-1,-2);p.setMargins(0,dp(t),0,0);return p;}
    private LinearLayout.LayoutParams marginTopHeight(int t,int h){LinearLayout.LayoutParams p=lp(-1,dp(h));p.setMargins(0,dp(t),0,0);return p;}
    private LinearLayout.LayoutParams weighted(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(54),1);p.setMargins(dp(3),0,dp(3),0);return p;}
    private int dp(int v){return(int)(v*getResources().getDisplayMetrics().density+.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private void setLoading(boolean b){if(progress!=null)progress.setVisibility(b?View.VISIBLE:View.GONE);}
    private void fail(String s){setLoading(false);toast(s);}

    interface Callback{void ok(String json);} static class Item{String code,name;Item(String c,String n){code=c;name=n;}}
    static class Module{String status,detail;Module(String s,String d){status=s;detail=d==null?"":d;}}
    static class VehicleReport{String plate,brand,model,version,year,color,fuel,city,state,chassis,renavam,fipe,fipeCode;Module auction,claim,theft,restrictions,debts,recall,ownerHistory,odometer;int score;}
}
